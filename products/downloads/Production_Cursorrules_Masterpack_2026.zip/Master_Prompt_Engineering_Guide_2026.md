# [The 2026 Solopreneur AI Engine] Production Prompt & Cursorrules Master Guide

**제작**: Hoiki AI Studio  
**버전**: v1.0 Production  
**대상**: 1인 개발자, 인디 해커, AI 기반 스타트업 창업가

---

## 1. 2026 AI 에이전트 오케스트레이션 4대 원칙
1. **맥락 격리 (Context Isolation)**: 프롬프트에 불필요한 전체 히스토리를 넣지 말고, 단일 기능 단위의 도메인 지식만 주입하라.
2. **엄격한 출력 제약 (Strict Output Constraint)**: 코드 블록 외의 사족(인사말, 설명, 요약)을 시스템 수준에서 원천 차단하라.
3. **결함 자가 검증 (Self-Healing Loop)**: 생성 즉시 린터/테스트를 실행하고 에러 발생 시 자동으로 디버깅하게 하라.
4. **인간적 리듬 유지 (De-AI Cadence)**: 문장 길이 변동계수(CV)를 0.5 이상으로 유지하여 로봇 특유의 패턴을 지워라.
